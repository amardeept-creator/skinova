# SKINIFY Build Report

Target platform: **Cloudflare Workers** (OpenNext) + R2 + optional Hyperdrive, with Neon Postgres.
Not deployed to Cloudflare yet: no Cloudflare account was connected. It has been built and tested locally on the real Workers runtime (workerd).
The earlier Vercel build is still live at https://skinify-ar.vercel.app (older code, Vercel Blob not connected).
Source: `/home/user/workspace/skinify` (git)

## WHAT WAS BUILT
An AR commerce platform with two sides:
- **Customers**: discovery, search and filters, product and brand pages, and live camera try-on in the browser. No account, no app.
- **Sellers**: brand onboarding, a 7-step Skinner builder, 3D asset pipeline, public links, QR codes, embeds, real analytics and plan limits.

There is also a platform admin console. It does no skin analysis, dermatology, scoring or medical features of any kind.

## COMPLETE ARCHITECTURE
- `app/(site)`: customer pages (home, explore, categories, brands, `p/[brand]/[product]`, `b/[brand]`, saved, pricing, how-it-works, privacy, developers, report).
- `app/s/[slug]`: public Skinner link. `app/embed/[slug]`: iframe. `app/try/[brand]/[product]`: readable alias.
- `app/(auth)`, `app/onboarding`, `app/dashboard/*` (overview, skinners, new, `[id]`, `[id]/preview`, analytics, links, assets, subscription, brand, account), `app/admin`.
- `app/api/*`: auth, me, account, search, events, assets (+token/finalize/[id]), brands, skinners (+actions), qr, report, billing (checkout/webhook), keys, admin, `v1/skinners`, `v1/analytics`.
- `lib/ar/*`: the **BODY-PART AR TRACKING ENGINE**, split into modules: profiles/config, vision loader, pure solvers per body part, One-Euro/pose filters, nail generator, engine (camera, render, occlusion, light estimation, capture), 3D viewer fallback.
- `lib/server/*`: db, sessions/auth, password hashing (scrypt), rate limit, storage driver, GLB validation and optimisation, entitlements, links, analytics, catalog.

## TECHNOLOGY STACK
Next.js 15 (App Router) + React 19 + TypeScript · PostgreSQL (`postgres` driver; Neon in production) · Cloudflare Workers via @opennextjs/cloudflare · Cloudflare R2 (uploads) · Hyperdrive (optional DB pooling) · MediaPipe Tasks Vision (on-device WASM/WebGL) · Three.js · glTF-Transform + meshoptimizer · qrcode · zod · Stripe via REST (optional).

## CUSTOMER EXPERIENCE
- The home hero reads "Try it. Before you buy it." with Explore / Create CTAs.
- The hero is a clearly labeled interactive 3D demo (drag to rotate), not a fake video.
- Rails for categories, trending (falls back to "featured" until there is real try-on data), new, and brands.
- Product cards show image, brand, name, price, TRY SKINNER and VIEW, with a tracker badge and a favourite button.
- Search and filters: category, brand, price, colour, trending, new, AR available.
- The product page puts TRY SKINNER first (sticky on mobile). It also has live variant chips, 3D view, a QR to open on a phone, share, a Buy link (disabled for demo brands) and report.
- AR flow: intro → permission → camera → tracking → the Skinner appears and follows.
- Camera controls: close, switch camera, photo/video capture, share, product info, reset, buy, variants.
- Loading screens: "Preparing your Skinner…", "Loading 3D product…", "Starting AR…".
- Designed failure screens: camera denied or unavailable, unsupported browser, tracking lost, model failure, network, expired or invalid link, product removed, seller inactive or subscription expired. A 3D-viewer fallback is always offered.

## SELLER EXPERIENCE
- Onboarding: signup → create brand (logo, name, description, website, accent) → first Skinner.
- The wizard has 7 steps: Product · 3D asset (upload / base model / library / none) · Skinner type (FACE HAND FINGER WRIST HEAD BODY FEET OTHER) · AR setup (anchor, size-fit, transform sliders, materials, variants) · Preview (live AR) · Publish (server-checked) · Share.
- Dashboard sections: Overview, My Skinners, Create Skinner, Analytics, Links & QR, 3D assets, Subscription, Brand settings, Account (profile, password, API keys).
- Skinner actions: edit, preview, publish/unpublish, duplicate, delete, renew link, copy link, QR, analytics.

## SKINNER SYSTEM
A Skinner is a product, a tracking profile, an AR configuration and an optional 3D asset. There are 13 profiles, each marked stable, beta or experimental in the UI:
- **Stable:** ring, watch, bracelet, glasses, lips.
- **Beta:** nails, earrings, hat, necklace, surface placement.
- **Experimental:** bag, clothing overlay, shoes.

Drafts never appear in discovery. Publish checks plan limits on the server.

## AR TRACKING SYSTEM
- Trackers are modular: hand (finger, wrist, nails), face (eyes, ears, lips, head), pose (neck, shoulder, feet, clothing) and surface.
- Solvers are pure functions that output a metric 6-DoF pose plus occluder volumes.
- Filtering is One-Euro. On tracking loss the Skinner **holds at its last pose and then fades**. It never floats around. The hold time adapts to slow devices.
- Occlusion comes from depth-only finger, wrist and head volumes. Lighting follows the camera image.
- No "100% accurate" or "perfect realism" claims are made anywhere.

## 3D ASSET SYSTEM
- Accepts GLB or self-contained GLTF.
- Validation checks magic bytes and the glTF 2.0 header, parses the model, and enforces a 400k-triangle limit and the plan's size limit.
- Inspection records meshes, materials and triangles, with warnings.
- Optimisation runs dedup + prune + Meshopt (the seed models shrank by about 70%).
- Scale is normalised with fit-to-size. PBR materials are supported, and variants can override materials.
- Loading is lazy with caching; Draco and Meshopt decoders are included. Stored files get immutable CDN caching.

## PUBLIC LINK SYSTEM
- Links look like `/s/{slug}`, with source attribution (`?src=qr|embed|discover|share`).
- Expiry comes from the plan. Links can be renewed.
- If a link is invalid, expired, disabled or the seller is inactive, customers see a friendly screen instead of a blank page.

## QR SYSTEM
`/api/qr/{slug}` serves SVG or PNG (up to 2048 px), with a download option. The dashboard can copy the QR image, print a display card and show a preview.

## SUBSCRIPTION SYSTEM
- Plans (Trial, Starter, Pro, Business, Enterprise) are **database rows**. Price, Stripe price ID and limits are edited in Admin → Plans, not in code.
- On expiry, Skinners become inactive but products and 3D assets are **kept**. Renewing restores them.
- Payments: online checkout returns an honest 501 until Stripe keys are set. Only a signature-verified webhook activates a paid plan; there are no fake successful payments. Admins can assign plans manually.

## DATABASE
Tables: users, sessions, sellers, brands, categories, products, product_variants, skinners, ar_assets, ar_configurations, tracking_profiles, public_links, subscriptions, subscription_plans, analytics_events, shares, favorites, reports, api_keys, admin_users. There is also a `live_skinners` view. Schema: `db/schema.sql`.

## ANALYTICS
- Only real events are counted: views, opens, camera starts, try-ons (at least 2 s of stable tracking), captures, shares, buy clicks, errors and session length.
- Seller previews are excluded. Demo data is flagged and gets no fabricated analytics.
- Traffic source and device breakdowns are shown on Pro and above.
- Note: the production DB currently holds ~20 events generated by my QA test runs.

## SECURITY
- Sessions: HttpOnly SameSite cookies, with hashed tokens stored in the DB.
- Passwords use scrypt.
- Every write API has a same-origin check.
- Each seller can only access their own data (ownership checked on every query).
- All input is validated with zod, and uploads are checked by magic bytes.
- Rate limits cover auth, events, uploads and reports.
- Admin routes use a separate admin_users check.
- CSP, frame-ancestors (only `/embed` can be framed), and a camera Permissions-Policy are set.
- React escaping protects against XSS.
- API keys are stored hashed. Secrets live only in env vars.

## PRIVACY
- Camera frames are processed only on the device and are never uploaded.
- Captures stay on the device unless the customer shares them.
- The camera stops on close, when the tab is hidden, and on exit.
- A privacy page explains all of this.

## PERFORMANCE
- The AR engine and 3D code load only on AR pages.
- The model, WASM and tracker downloads start in parallel with the camera prompt.
- Images and assets use immutable caching and are lazy-loaded.
- Pages are server-rendered and use the pooled DB connection.

## CLOUDFLARE DEPLOYMENT
- Runtime: Next.js on Cloudflare Workers via OpenNext. Configuration is in `wrangler.jsonc` and `open-next.config.ts`.
- Bundle size: ~1.9 MB gzipped, which fits both the Free (3 MB) and Paid (10 MB) limits. The Paid plan is recommended because of the Free plan's 10 ms CPU limit per request.
- Bindings: `MEDIA` (R2 bucket `skinify-media`, required for uploads), `HYPERDRIVE` (optional), `ASSETS` (static files).
- The code talks to Cloudflare through `lib/server/cf.ts`:
  - Each request gets its own Postgres client, because Workers can't share sockets across requests. It goes through Hyperdrive when that's bound.
  - Storage is R2 (`put`/`get`/`delete` by key), and uploads are served from `/api/files/*`.
  - Visitor IPs come from `cf-connecting-ip`.
- Verified locally on workerd:
  - Every public page, the dashboard and admin pages load.
  - Login works (scrypt runs on Workers).
  - A GLB model and an image uploaded into R2 and were read back correctly.
  - A Skinner was created, published and found in search, and its public link and QR both return 200.
  - Live AR loaded the uploaded model from R2 and showed "Finger tracked".
- CI: `.github/workflows/deploy-cloudflare.yml` deploys on every push to `main`.
- Vercel Blob was removed from the code. Your Vercel projects were left unchanged.

## FULLY FUNCTIONAL FEATURES
(Verified in this build unless noted.)
- Discovery, search, filters, product and brand pages, favourites (stored on the device).
- Seller signup, login and onboarding (signup verified in production).
- Wizard end-to-end: a real GLB was uploaded, validated and optimised, then published, which created a link and QR.
- Public links and failure states. I verified that when an admin disables a Skinner, its link shows "unavailable", and that re-enabling restores it.
- QR SVG/PNG, embed code, analytics recording and dashboards.
- Plan limits and data-driven plans, admin moderation, API keys and `/api/v1`.
- Live AR for **ring** (verified in production with a fake camera feed of a real hand photo) and **glasses** (verified locally with a portrait photo).

## PARTIALLY FUNCTIONAL FEATURES
- The other AR profiles are implemented but I did not verify them against real bodies this session: watch, bracelet, earrings, lips, nails, hat, necklace.
- The ring's stone can tilt sideways on flat photos.
- Glasses frames render dark grey rather than deep black.
- The experimental profiles (bag, clothing overlay, shoes) have low precision.
- Photo/video capture and native share are built but were not tested on a phone.
- The rate limit is per instance (in memory), not global.

## FEATURES REQUIRING EXTERNAL SERVICES
- **A Cloudflare account** is needed to deploy: run `wrangler login` or provide an API token. You also need an R2 bucket (`npx wrangler r2 bucket create skinify-media`). If the `MEDIA` binding is missing, uploads show a clear "storage not configured" message; base models still work.
- **Card payments need Stripe:** set `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET`, plus a price ID per plan.
- Tracking models load from Google's CDN by default; they can be self-hosted.
- A strict global rate limit needs Cloudflare WAF rate-limiting rules or the Workers Rate Limiting binding.
- **No server-side GLB compression on Workers.** Workers block runtime WASM compilation and native `sharp`. Uploads are still fully validated from the glTF metadata (triangles, bounds including quantized meshes, required extensions, plan size) and stored as uploaded. Compression still runs under Node (local dev and the seed script).

## FEATURES REQUIRING REAL 3D ASSETS
The 16 demo models are procedural placeholders I generated. Real products need real GLB scans or models from each brand for true-to-life appearance.

## KNOWN LIMITATIONS
- Nothing was tested on real phones. My QA ran on CPU-only Chromium at about 1 fps.
- First load on slow devices can take several seconds.
- The demo seller account owns all 6 demo brands, so anyone signed in as it can edit the public demo catalogue.
- Clothing is a 2D overlay, not a cloth simulation.
- Purchases happen on the seller's own store and are not tracked by SKINIFY.

## HOW TO CREATE A NEW SKINNER
1. Dashboard → Create Skinner.
2. Enter product info and add at least one image.
3. Upload a GLB, or pick a base model.
4. Choose the body part.
5. Adjust fit and variants.
6. Start live preview.
7. Publish.
8. Share.

## HOW A SELLER SHARES A SKINNER
On the Share step or in Links & QR you can:
- Copy the link or share it natively.
- Download the QR as PNG/SVG, copy it, or print a display card.
- Copy the iframe embed code or the SDK button (plans with embed only).

## HOW A CUSTOMER DISCOVERS AND USES A SKINNER
1. Browse, search or scan a QR.
2. Tap TRY SKINNER.
3. Allow the camera.
4. Show the body part.
5. Switch variants, capture, share or buy.
6. If the camera isn't available, use the 3D view.

## HOW TO DEPLOY TO CLOUDFLARE
See `README.md` for the full steps. In short, using Node 22:
1. `npm install`
2. `npx wrangler login`
3. `npx wrangler r2 bucket create skinify-media`
4. Optional: `npx wrangler hyperdrive create skinify-db --connection-string='…'`, then paste the id into `wrangler.jsonc`.
5. `npx wrangler secret put DATABASE_URL`
6. Set `vars.SITE_URL` in `wrangler.jsonc`.
7. Run `npm run db:migrate && npm run db:seed` against Neon. Your Neon DB is already migrated and seeded.
8. `npm run cf:deploy`

## ENVIRONMENT VARIABLES REQUIRED
- Required: `DATABASE_URL` (secret) and `SITE_URL` (var).
- Required for uploads: the `MEDIA` R2 binding (a binding, not an env var).
- Optional: the `HYPERDRIVE` binding, and `R2_PUBLIC_URL` (build time) for a CDN custom domain on the bucket.
- Optional: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `NEXT_PUBLIC_MEDIAPIPE_WASM_BASE`, `NEXT_PUBLIC_MP_*`, `NEXT_PUBLIC_DRACO_DECODER_PATH`.
- Seed only: `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `DEMO_SELLER_EMAIL`, `DEMO_SELLER_PASSWORD`, `SEED_DEMO`.

## FUTURE ROADMAP
- Real-device calibration per profile.
- WebXR surface placement.
- Shopify and WooCommerce apps built on the SDK.
- Email verification and password reset.
- Global rate limiting (Workers Rate Limiting binding).
- Client-side GLB compression before upload, so Workers deployments also get compressed models.
- Signed short-lived links for private previews.
- Brand teams and roles.
- A/B variants.
- Server-side USDZ export for iOS Quick Look.

## FINAL AUDIT
**Customer**
- Home, explore, search, filters, product page and brand page: done.
- AR ring (production) and glasses: done.
- Invalid link → 404 page, and disabled link → unavailable screen: done.
- Mobile layout at 375 px with no horizontal overflow: done.
- AR for the other profiles on real devices: NOT verified.

**Seller**
- Login, dashboard, wizard, GLB upload and validation, publish, link, QR and embed: done.
- Analytics, subscription page with the honest billing notice, and assets: done.
- Upload to R2 on the Workers runtime: done (tested locally).
- Deploy to Cloudflare: waiting on a Cloudflare account.

**System**
- Typecheck and production build are clean. The build is deployed and live.
- Production signup: done (the probe account was deleted afterwards).
- Admin disable/enable and plan editor: done.
- Stripe: not configured.
