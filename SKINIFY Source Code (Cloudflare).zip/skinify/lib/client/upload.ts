'use client';
export type Kind = 'model' | 'image' | 'video';
const EDGE_MAX = 95 * 1048576; // Cloudflare Free/Pro request-body limit is 100 MB
export interface UploadedAsset { id: string; kind: Kind; url: string; mime: string; bytes: number; original_bytes: number; original_filename: string; meta: Record<string, unknown> }
/** Uploads a file to /api/assets (multipart) with real progress; the server sniffs, validates, stores in R2 and records it. */
export function uploadAsset(file: File, kind: Kind, onProgress?: (p: number) => void): Promise<UploadedAsset> {
  const ext = file.name.split('.').pop()?.toLowerCase();
  if (kind === 'model' && !['glb', 'gltf'].includes(ext || '')) return Promise.reject(new Error('3D models must be .glb or .gltf files.'));
  if (file.size > EDGE_MAX) return Promise.reject(new Error('Files must be under 95 MB.'));
  return new Promise((resolve, reject) => {
    const fd = new FormData(); fd.append('file', file); fd.append('kind', kind);
    const x = new XMLHttpRequest();
    x.open('POST', '/api/assets');
    x.upload.onprogress = (e) => { if (e.lengthComputable) onProgress?.(e.loaded / e.total * 0.9); };
    x.onerror = () => reject(new Error('Network error while uploading. Check your connection and try again.'));
    x.onload = () => {
      let d: { asset?: UploadedAsset; error?: string } = {};
      try { d = JSON.parse(x.responseText); } catch { /* non-JSON */ }
      if (x.status >= 200 && x.status < 300 && d.asset) { onProgress?.(1); resolve(d.asset); }
      else reject(new Error(d.error || (x.status === 413 ? 'File is too large.' : 'Upload failed')));
    };
    x.send(fd);
  });
}
