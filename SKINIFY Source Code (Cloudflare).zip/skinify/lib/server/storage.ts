import 'server-only';
import { cf } from './cf';

/**
 * Object storage abstraction.
 *  - Cloudflare (production): R2 bucket bound as `MEDIA`. Files are served by /api/files/* from
 *    the Worker with immutable caching, or straight from an R2 public/custom domain when
 *    R2_PUBLIC_URL is set (recommended: put a custom domain on the bucket so Cloudflare's CDN serves it).
 *  - Local development / plain Node: .data/uploads served by /api/files/*.
 * Large 3D assets never live in the application bundle.
 */
export type Driver = 'r2' | 'local' | 'none';
export function storageDriver(): Driver {
  const c = cf();
  if (c) return c.env.MEDIA ? 'r2' : 'none';
  if (process.env.STORAGE_DRIVER === 'none') return 'none';
  return 'local';
}

function publicUrl(key: string) {
  const base = process.env.R2_PUBLIC_URL?.replace(/\/$/, '');
  return base ? `${base}/${key}` : `/api/files/${key}`;
}

async function localRoot() {
  const path = await import('path');
  return path.join(process.cwd(), '.data', 'uploads');
}

export async function putObject(key: string, body: Uint8Array, contentType: string) {
  const d = storageDriver();
  if (d === 'r2') {
    await cf()!.env.MEDIA!.put(key, body, { httpMetadata: { contentType, cacheControl: 'public, max-age=31536000, immutable' } });
    return { key, url: publicUrl(key) };
  }
  if (d === 'local') {
    const { promises: fs } = await import('fs'); const path = await import('path');
    const p = path.join(await localRoot(), key); await fs.mkdir(path.dirname(p), { recursive: true }); await fs.writeFile(p, body);
    return { key, url: `/api/files/${key}` };
  }
  throw new Error('STORAGE_NOT_CONFIGURED');
}

/** Returns a streaming body for /api/files/*, or null when missing. */
export async function readObject(key: string): Promise<{ body: ReadableStream | Uint8Array; type?: string; etag?: string } | null> {
  const d = storageDriver();
  if (d === 'r2') {
    const o = await cf()!.env.MEDIA!.get(key); if (!o) return null;
    return { body: o.body, type: o.httpMetadata?.contentType, etag: o.httpEtag };
  }
  if (d === 'local') {
    const { promises: fs } = await import('fs'); const path = await import('path');
    const root = await localRoot(); const p = path.normalize(path.join(root, key));
    if (!p.startsWith(root)) return null;
    try { return { body: new Uint8Array(await fs.readFile(p)) }; } catch { return null; }
  }
  return null;
}

/** Deletes by storage key (never by arbitrary URL). */
export async function deleteObject(key: string) {
  try {
    const d = storageDriver();
    if (d === 'r2') await cf()!.env.MEDIA!.delete(key);
    else if (d === 'local') { const { promises: fs } = await import('fs'); const path = await import('path'); const root = await localRoot(); const p = path.normalize(path.join(root, key)); if (p.startsWith(root)) await fs.unlink(p); }
  } catch (e) { console.warn('[storage] delete failed', e); }
}
