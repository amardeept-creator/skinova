import 'server-only';
import postgres from 'postgres';
import { cf } from './cf';

type Sql = ReturnType<typeof postgres>;
declare global {
  // eslint-disable-next-line no-var
  var __skinifySql: Sql | undefined;
}

function create(hyperdrive?: string): Sql {
  const url = hyperdrive || process.env.DATABASE_URL;
  if (!url) throw new Error('DATABASE_URL is not configured. See .env.example.');
  const local = /localhost|127\.0\.0\.1/.test(url) || !!hyperdrive; // Hyperdrive terminates TLS itself
  return postgres(url, {
    max: hyperdrive ? 5 : local ? 1 : Number(process.env.DB_POOL_MAX || 5),
    ssl: local ? false : 'require',
    prepare: false, // required for PgBouncer / Neon pooled connections
    idle_timeout: 20,
    connect_timeout: 15,
    transform: { undefined: null },
  });
}
// Cloudflare Workers cannot share sockets between requests, so each request gets its own client
// (through Hyperdrive when bound, which keeps the real connection pool warm at the edge).
const perRequest = new WeakMap<object, Sql>();
function get(): Sql {
  const c = cf();
  if (c) {
    let s = perRequest.get(c.ctx);
    if (!s) { s = create(c.env.HYPERDRIVE?.connectionString); perRequest.set(c.ctx, s); }
    return s;
  }
  return (globalThis.__skinifySql ??= create());
}

/** Lazily-connected client: importing this module never opens a connection (safe at build time). */
export const sql: Sql = new Proxy(function () {} as unknown as Sql, {
  apply: (_t, _this, args: unknown[]) => (get() as unknown as (...a: unknown[]) => unknown)(...args),
  get: (_t, p) => { const s = get() as unknown as Record<string | symbol, unknown>; const v = s[p]; return typeof v === 'function' ? (v as (...a: unknown[]) => unknown).bind(s) : v; },
});
