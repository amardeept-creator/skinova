import 'server-only';
import { NodeIO, type Node as GNode, type Scene } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import { isWorkers } from './cf';

// @gltf-transform/functions (→ sharp) and meshoptimizer (runtime WASM compile) cannot load on
// Cloudflare Workers, so they are imported lazily and only where the runtime supports them.
async function loadOptimiser() {
  if (isWorkers) return null;
  try {
    const [fn, mo] = await Promise.all([import('@gltf-transform/functions'), import('meshoptimizer')]);
    await Promise.all([mo.MeshoptDecoder.ready, mo.MeshoptEncoder.ready]);
    return { ...fn, MeshoptDecoder: mo.MeshoptDecoder, MeshoptEncoder: mo.MeshoptEncoder };
  } catch { return null; }
}

/** World-space AABB of all mesh POSITION accessors (dependency-free replacement for getBounds). */
function sceneBounds(scene: Scene) {
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  scene.traverse((node: GNode) => {
    const mesh = node.getMesh(); if (!mesh) return;
    const m = node.getWorldMatrix();
    for (const prim of mesh.listPrimitives()) {
      const pos = prim.getAttribute('POSITION'); if (!pos) continue;
      const lo = pos.getMin([]), hi = pos.getMax([]);
      for (let c = 0; c < 8; c++) {
        const x = c & 1 ? hi[0] : lo[0], y = c & 2 ? hi[1] : lo[1], z = c & 4 ? hi[2] : lo[2];
        const w = [m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13], m[2] * x + m[6] * y + m[10] * z + m[14]];
        for (let i = 0; i < 3; i++) { if (w[i] < min[i]) min[i] = w[i]; if (w[i] > max[i]) max[i] = w[i]; }
      }
    }
  });
  if (!isFinite(min[0])) return { min: [0, 0, 0], max: [0, 0, 0] };
  return { min, max };
}

export interface GlbReport {
  ok: boolean; error?: string; warnings: string[];
  bytesIn: number; bytesOut: number; optimized: boolean;
  bbox?: { min: number[]; max: number[]; size: number[] };
  triangles: number; meshes: number; materials: string[]; textures: number; maxTextureSize: number; extensions: string[];
}

const MAX_TRIS = 400_000;

/** Structural validation of a binary glTF 2.0 container before any parsing. */
export function sniffGlb(buf: Uint8Array): string | null {
  if (buf.length < 20) return 'File is too small to be a GLB.';
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  if (dv.getUint32(0, true) !== 0x46546c67) return 'Not a GLB file (missing glTF header). Export your model as .glb (binary glTF 2.0).';
  if (dv.getUint32(4, true) !== 2) return 'Only glTF 2.0 is supported.';
  if (dv.getUint32(8, true) !== buf.length) return 'GLB length header does not match the file size (corrupt upload?).';
  if (dv.getUint32(16, true) !== 0x4e4f534a) return 'GLB is missing its JSON chunk.';
  return null;
}

export async function processGlb(input: Uint8Array): Promise<{ report: GlbReport; output: Uint8Array }> {
  const warnings: string[] = [];
  const base: GlbReport = { ok: false, warnings, bytesIn: input.length, bytesOut: input.length, optimized: false, triangles: 0, meshes: 0, materials: [], textures: 0, maxTextureSize: 0, extensions: [] };
  const sniff = sniffGlb(input); if (sniff) return { report: { ...base, error: sniff }, output: input };
  // meshoptimizer compiles WebAssembly from bytes at runtime. Cloudflare Workers forbid that, so there
  // the model is validated and stored as uploaded (sellers can pre-compress; the browser still decodes it).
  const opt = await loadOptimiser();
  let json: GltfJson;
  try { json = readGlbJson(input); } catch { return { report: { ...base, error: 'The GLB JSON chunk is corrupt.' }, output: input }; }
  const compressed = (json.extensionsUsed || []).some(e => e === 'KHR_draco_mesh_compression' || e === 'EXT_meshopt_compression');
  // Compressed geometry can't be decoded where the WASM decoders are unavailable (Cloudflare Workers),
  // so it is validated from the glTF JSON itself: accessor counts and the spec-required POSITION min/max.
  if (compressed && !opt) return inspectFromJson(json, base, warnings, input);
  const io = new NodeIO().registerExtensions(ALL_EXTENSIONS);
  if (opt) io.registerDependencies({ 'meshopt.decoder': opt.MeshoptDecoder, 'meshopt.encoder': opt.MeshoptEncoder });
  let doc;
  try { doc = await io.readBinary(input); }
  catch (e) {
    const msg = String((e as Error).message || e);
    if (/draco/i.test(msg)) return inspectFromJson(json, base, warnings, input);
    return { report: { ...base, error: 'The GLB could not be parsed: ' + msg.slice(0, 160) }, output: input };
  }
  const root = doc.getRoot();
  const scene = root.getDefaultScene() || root.listScenes()[0];
  if (!scene) return { report: { ...base, error: 'The GLB contains no scene.' }, output: input };
  let tris = 0;
  for (const mesh of root.listMeshes()) for (const prim of mesh.listPrimitives()) {
    const idx = prim.getIndices(); const pos = prim.getAttribute('POSITION');
    const mode = prim.getMode();
    if (mode === 4) tris += (idx ? idx.getCount() : pos?.getCount() || 0) / 3;
  }
  const meshes = root.listMeshes().length;
  if (!meshes) return { report: { ...base, error: 'The GLB contains no meshes.' }, output: input };
  if (tris > MAX_TRIS) return { report: { ...base, triangles: tris, error: `Model has ${Math.round(tris).toLocaleString()} triangles; the limit is ${MAX_TRIS.toLocaleString()}. Please decimate it for mobile AR.` }, output: input };
  let maxTex = 0;
  for (const t of root.listTextures()) { const s = t.getSize(); if (s) maxTex = Math.max(maxTex, s[0], s[1]); }
  if (maxTex > 4096) warnings.push(`Largest texture is ${maxTex}px; 2048px or less is recommended for mobile.`);
  if (tris > 150_000) warnings.push('High polygon count may reduce frame rate on older phones.');
  const b = sceneBounds(scene);
  const size = [0, 1, 2].map(i => b.max[i] - b.min[i]);
  if (Math.max(...size) > 50) warnings.push('Model appears to be authored in centimetres or millimetres; SKINIFY will rescale it to real-world size.');
  const materials = root.listMaterials().map(m => m.getName() || '').filter(Boolean);
  const exts = root.listExtensionsUsed().map(e => e.extensionName);
  let output = input, optimized = false;
  if (!opt) warnings.push('Server-side compression is not available on this runtime; the model was stored as uploaded.');
  else try {
    await doc.transform(opt.dedup(), opt.prune(), opt.meshopt({ encoder: opt.MeshoptEncoder, level: 'medium' }));
    const out = await io.writeBinary(doc);
    if (out.length < input.length) { output = out; optimized = true; }
  } catch (e) { warnings.push('Optimisation skipped: ' + String((e as Error).message).slice(0, 120)); }
  return { report: { ...base, ok: true, bytesOut: output.length, optimized, bbox: { min: [...b.min], max: [...b.max], size }, triangles: Math.round(tris), meshes, materials, textures: root.listTextures().length, maxTextureSize: maxTex, extensions: exts }, output };
}

interface GltfJson {
  asset?: { version?: string }; scene?: number; scenes?: { nodes?: number[] }[];
  nodes?: { mesh?: number; children?: number[]; matrix?: number[]; translation?: number[]; rotation?: number[]; scale?: number[] }[];
  meshes?: { primitives: { attributes: Record<string, number>; indices?: number; mode?: number }[] }[];
  accessors?: { count: number; min?: number[]; max?: number[]; componentType?: number; normalized?: boolean }[];
  materials?: { name?: string }[]; textures?: unknown[]; extensionsUsed?: string[]; extensionsRequired?: string[];
}
function readGlbJson(buf: Uint8Array): GltfJson {
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  const len = dv.getUint32(12, true);
  if (20 + len > buf.length) throw new Error('bad chunk');
  return JSON.parse(new TextDecoder().decode(buf.subarray(20, 20 + len)));
}
type M4 = number[];
function mul(a: M4, b: M4): M4 { const o = new Array(16).fill(0); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) for (let k = 0; k < 4; k++) o[c * 4 + r] += a[k * 4 + r] * b[c * 4 + k]; return o; }
function trs(n: NonNullable<GltfJson['nodes']>[number]): M4 {
  if (n.matrix?.length === 16) return n.matrix;
  const [x, y, z, w] = n.rotation || [0, 0, 0, 1]; const [sx, sy, sz] = n.scale || [1, 1, 1]; const [tx, ty, tz] = n.translation || [0, 0, 0];
  return [(1 - 2 * (y * y + z * z)) * sx, 2 * (x * y + z * w) * sx, 2 * (x * z - y * w) * sx, 0,
    2 * (x * y - z * w) * sy, (1 - 2 * (x * x + z * z)) * sy, 2 * (y * z + x * w) * sy, 0,
    2 * (x * z + y * w) * sz, 2 * (y * z - x * w) * sz, (1 - 2 * (x * x + y * y)) * sz, 0, tx, ty, tz, 1];
}
/** Validation + inspection straight from the glTF JSON (no geometry decoding). */
function inspectFromJson(json: GltfJson, base: GlbReport, warnings: string[], input: Uint8Array): { report: GlbReport; output: Uint8Array } {
  const fail = (error: string) => ({ report: { ...base, error }, output: input });
  if (!json.asset?.version?.startsWith('2')) return fail('Only glTF 2.0 is supported.');
  const known = new Set(ALL_EXTENSIONS.map(e => e.EXTENSION_NAME));
  const unknown = (json.extensionsRequired || []).filter(e => !known.has(e));
  if (unknown.length) return fail('The model requires unsupported extensions: ' + unknown.join(', '));
  const meshes = json.meshes || []; const acc = json.accessors || []; const nodes = json.nodes || [];
  if (!meshes.length) return fail('The GLB contains no meshes.');
  const scene = json.scenes?.[json.scene ?? 0]; if (!scene) return fail('The GLB contains no scene.');
  let tris = 0; const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  const visit = (i: number, parent: M4, depth: number) => {
    const n = nodes[i]; if (!n || depth > 64) return;
    const m = mul(parent, trs(n));
    if (n.mesh != null) for (const p of meshes[n.mesh]?.primitives || []) {
      const pos = acc[p.attributes.POSITION]; if (!pos) continue;
      if ((p.mode ?? 4) === 4) tris += (p.indices != null ? acc[p.indices]?.count || 0 : pos.count) / 3;
      // KHR_mesh_quantization: normalized integer bounds are stored in integer space
      const q = pos.normalized ? ({ 5120: 127, 5121: 255, 5122: 32767, 5123: 65535 } as Record<number, number>)[pos.componentType || 0] || 1 : 1;
      if (pos.min && pos.max) for (let c = 0; c < 8; c++) {
        const x = (c & 1 ? pos.max[0] : pos.min[0]) / q, y = (c & 2 ? pos.max[1] : pos.min[1]) / q, z = (c & 4 ? pos.max[2] : pos.min[2]) / q;
        const w = [m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13], m[2] * x + m[6] * y + m[10] * z + m[14]];
        for (let k = 0; k < 3; k++) { if (w[k] < min[k]) min[k] = w[k]; if (w[k] > max[k]) max[k] = w[k]; }
      }
    }
    for (const c of n.children || []) visit(c, m, depth + 1);
  };
  const I = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
  for (const r of scene.nodes || []) visit(r, I, 0);
  if (!isFinite(min[0])) return fail('The model has no measurable geometry (missing POSITION bounds).');
  if (tris > MAX_TRIS) return fail(`Model has ${Math.round(tris).toLocaleString()} triangles; the limit is ${MAX_TRIS.toLocaleString()}. Please decimate it for mobile AR.`);
  if (tris > 150_000) warnings.push('High polygon count may reduce frame rate on older phones.');
  const size = [0, 1, 2].map(i => max[i] - min[i]);
  if (Math.max(...size) > 50) warnings.push('Model appears to be authored in centimetres or millimetres; SKINIFY will rescale it to real-world size.');
  warnings.push('Compressed model validated from its glTF metadata and stored as uploaded.');
  return { report: { ...base, ok: true, bbox: { min, max, size }, triangles: Math.round(tris), meshes: meshes.length, materials: (json.materials || []).map(m => m.name || '').filter(Boolean), textures: (json.textures || []).length, maxTextureSize: 0, extensions: json.extensionsUsed || [] }, output: input };
}

export function sniffImage(buf: Uint8Array): string | null {
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 && buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50) return 'image/webp';
  return null;
}
export function sniffVideo(buf: Uint8Array): string | null {
  if (buf[4] === 0x66 && buf[5] === 0x74 && buf[6] === 0x79 && buf[7] === 0x70) return 'video/mp4';
  if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return 'video/webm';
  return null;
}

/** Self-contained .gltf (JSON with data: URIs) → GLB. External-file .gltf must be packed by the seller. */
export async function gltfJsonToGlb(buf: Uint8Array): Promise<Uint8Array> {
  const text = Buffer.from(buf).toString('utf8');
  const json = JSON.parse(text);
  const ext = [...(json.buffers || []), ...(json.images || [])].some((b: { uri?: string }) => b.uri && !b.uri.startsWith('data:'));
  if (ext) throw new Error('This .gltf references external files. Export as a single .glb (binary glTF) or embed textures.');
  const opt = await loadOptimiser();
  const io = new NodeIO().registerExtensions(ALL_EXTENSIONS);
  if (opt) io.registerDependencies({ 'meshopt.decoder': opt.MeshoptDecoder });
  const doc = await io.readJSON({ json, resources: {} });
  return io.writeBinary(doc);
}
