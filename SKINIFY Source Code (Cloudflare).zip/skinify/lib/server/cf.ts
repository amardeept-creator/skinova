import 'server-only';
import { getCloudflareContext } from '@opennextjs/cloudflare';
/**
 * Cloudflare runtime access. On Cloudflare Workers (via OpenNext) this returns the request's
 * bindings (R2 bucket, Hyperdrive) and ExecutionContext. In plain Node (local dev, `next start`)
 * it returns null so callers fall back to env vars / local storage.
 */
export interface CfEnv {
  MEDIA?: R2Like;
  HYPERDRIVE?: { connectionString: string };
  [k: string]: unknown;
}
export interface R2Like {
  put(key: string, value: ArrayBuffer | Uint8Array | ReadableStream, opts?: { httpMetadata?: { contentType?: string; cacheControl?: string } }): Promise<unknown>;
  get(key: string): Promise<{ body: ReadableStream; size: number; httpEtag: string; httpMetadata?: { contentType?: string } } | null>;
  delete(key: string): Promise<void>;
}
export const isWorkers = typeof navigator !== 'undefined' && navigator.userAgent === 'Cloudflare-Workers';

export function cf(): { env: CfEnv; ctx: object } | null {
  if (!isWorkers) return null;
  try {
    const c = getCloudflareContext();
    return { env: c.env as unknown as CfEnv, ctx: c.ctx as object };
  } catch { return null; }
}
