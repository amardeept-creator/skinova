import { defineCloudflareConfig } from '@opennextjs/cloudflare';
import staticAssetsIncrementalCache from '@opennextjs/cloudflare/overrides/incremental-cache/static-assets-incremental-cache';

// SKINIFY pages are either fully dynamic (catalogue, dashboard, AR links) or static without
// revalidation, so a read-only static-assets cache is sufficient — no KV/R2 cache bucket needed.
export default defineCloudflareConfig({
  incrementalCache: staticAssetsIncrementalCache,
  enableCacheInterception: true,
});
