import { readObject } from '@/lib/server/storage';
const TYPES: Record<string, string> = { glb: 'model/gltf-binary', png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', mp4: 'video/mp4', webm: 'video/webm' };
/** Serves uploaded assets from R2 (Cloudflare) or .data/uploads (local). Keys are immutable, so caching is permanent. */
export async function GET(req: Request, ctx: { params: Promise<{ key: string[] }> }) {
  const key = (await ctx.params).key.join('/');
  if (!/^sellers\/[\w\-/.]+$/.test(key) || key.includes('..')) return new Response('Bad key', { status: 400 });
  const o = await readObject(key);
  if (!o) return new Response('Not found', { status: 404 });
  if (o.etag && req.headers.get('if-none-match') === o.etag) return new Response(null, { status: 304 });
  const h: Record<string, string> = { 'content-type': o.type || TYPES[key.split('.').pop() || ''] || 'application/octet-stream', 'cache-control': 'public, max-age=31536000, immutable', 'x-content-type-options': 'nosniff', 'access-control-allow-origin': '*' };
  if (o.etag) h.etag = o.etag;
  return new Response(o.body as BodyInit, { headers: h });
}
