# SKINIFY — Try it. Before you buy it.

SKINIFY is an AR commerce platform. Brands turn products into **Skinners**: browser-based AR try-on experiences they can share anywhere as a link, QR code or embed. Customers find products and try them on with their camera. There is no app to install and no account to create.

> SKINIFY is **not** a skin-analysis, dermatology or skincare product. It does no diagnosis or medical analysis of any kind.

## Stack (Cloudflare-first)

| Layer | Choice |
| --- | --- |
| App | Next.js 15 (App Router, React 19, TypeScript), running on **Cloudflare Workers** via the OpenNext adapter (`@opennextjs/cloudflare`) |
| Static files | Workers Static Assets (JS/CSS, demo models and images, MediaPipe WASM), served from Cloudflare's CDN |
| Database | PostgreSQL on Neon via the `postgres` driver, optionally pooled through **Cloudflare Hyperdrive** |
| Seller uploads | **Cloudflare R2** bucket bound as `MEDIA`. Files are served by `/api/files/*` with immutable caching, or from an R2 custom domain |
| AR tracking | MediaPipe Tasks Vision (hand / face / pose / segmentation), running on the device via WebGL/WASM |
| Rendering | Three.js (PBR materials, Draco and Meshopt decoding, depth occluders, lighting estimated from the camera) |
| 3D pipeline | glTF-Transform validation and inspection. Server-side compression runs in Node only; see limitations |
| Billing | Stripe Checkout with signed webhooks. Optional; disabled until keys are set |

Local development still runs in plain Node (`npm run dev`). Uploads go to `.data/`, and any Postgres works.

## Project layout

```
app/(site)          customer pages: home, explore, categories, brands, product, brand store, saved, pricing, docs
app/s/[slug]        public Skinner link (full-screen AR)      app/embed/[slug]  iframe embed
app/try/[b]/[p]     readable alias → /s/[slug]                 app/(auth)        login / signup
app/onboarding      seller onboarding (brand → first Skinner)  app/dashboard/*   seller studio
app/admin           platform admin                             app/api/*         JSON APIs (+ /api/v1 public API)
lib/ar/*            BODY-PART AR TRACKING ENGINE (config, vision loader, solvers, filters, nails, engine, viewer)
lib/server/cf.ts    Cloudflare bindings access (R2, Hyperdrive, ExecutionContext) with Node fallback
lib/server/*        db, auth, sessions, rate limit, storage (R2/local), GLB validation, entitlements, links, analytics
db/schema.sql       full schema     scripts/migrate.mjs, scripts/seed.ts
wrangler.jsonc      Worker config (bindings)   open-next.config.ts   OpenNext adapter config
```

## Local development (Node)

```bash
npm install
cp .env.example .env.local        # set DATABASE_URL (any Postgres 14+)
npm run db:migrate                # creates tables (idempotent)
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='choose-a-strong-one' DEMO_SELLER_PASSWORD='another-one' npm run db:seed
npm run dev                       # http://localhost:3000
```

The camera only works over HTTPS or on `localhost`.

To run the real Workers runtime locally (workerd, simulated R2): put `DATABASE_URL=…` and `SITE_URL=http://localhost:8787` in `.dev.vars`, then run `npm run cf:preview`.

## Deploying to Cloudflare

Requires Node **22+** and a Cloudflare account. The Workers **Paid** plan ($5/mo) is strongly recommended. On the Free plan, Workers get 10 ms CPU per request, which server-rendered pages and password hashing can exceed. The bundle (~1.9 MB gzipped) fits both plans' size limits.

1. **Log in:** run `npx wrangler login`, or set `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID`. The token needs Workers Scripts:Edit, Workers R2 Storage:Edit and, optionally, Hyperdrive:Edit.
2. **Database:** create a Neon project and copy the connection string. Then migrate and seed once from your machine:
   ```bash
   DATABASE_URL='postgresql://…neon.tech/neondb?sslmode=require' npm run db:migrate
   DATABASE_URL='…' ADMIN_EMAIL=… ADMIN_PASSWORD=… DEMO_SELLER_PASSWORD=… npm run db:seed   # SEED_DEMO=false to skip demo brands
   ```
3. **R2 bucket for uploads:**
   ```bash
   npx wrangler r2 bucket create skinify-media
   ```
   Optional: in the Cloudflare dashboard, attach a custom domain to the bucket (e.g. `media.yourdomain.com`), then set `R2_PUBLIC_URL` at build time. Media is then served straight from Cloudflare's CDN instead of through the Worker.
4. **Hyperdrive (recommended):**
   ```bash
   npx wrangler hyperdrive create skinify-db --connection-string='postgresql://…neon.tech/neondb?sslmode=require'
   ```
   Uncomment the `hyperdrive` block in `wrangler.jsonc` and paste the id. Without Hyperdrive, the Worker connects directly using the `DATABASE_URL` secret. That works, but each request opens a new connection.
5. **Secrets and vars:**
   ```bash
   npx wrangler secret put DATABASE_URL          # still needed as fallback + for scripts
   npx wrangler secret put STRIPE_SECRET_KEY     # optional
   npx wrangler secret put STRIPE_WEBHOOK_SECRET # optional
   ```
   In `wrangler.jsonc`, set `vars.SITE_URL` to your final origin (e.g. `https://skinify.<subdomain>.workers.dev` or a custom domain).
6. **Deploy:**
   ```bash
   npm run cf:deploy     # = opennextjs-cloudflare build && opennextjs-cloudflare deploy
   ```
   For Git-based deploys, connect the repo in Cloudflare → Workers → Create → Import repository. Use build command `npx opennextjs-cloudflare build` and deploy command `npx opennextjs-cloudflare deploy` on Node 22.
7. **Custom domain:** Workers → skinify → Settings → Domains & Routes. Update `SITE_URL` to match.
8. **Stripe webhook:** point it at `https://<domain>/api/billing/webhook` with the events `customer.subscription.created`, `customer.subscription.updated` and `customer.subscription.deleted`. Only a signature-verified webhook activates a paid plan.

### Rate limiting

`lib/server/ratelimit.ts` is in-memory per Worker isolate, which stops bursts but isn't a global quota. For strict global limits, add Cloudflare WAF rate-limiting rules for `/api/auth/*`, `/api/assets` and `/api/events`, or use the Workers Rate Limiting binding. Visitor IPs come from `cf-connecting-ip`.

## Cloudflare-specific limitations (honest)

- **No server-side GLB compression on Workers.** meshoptimizer compiles WebAssembly at runtime, and glTF-Transform's `functions` package pulls in `sharp`; Workers allow neither. Uploads are still fully validated on Workers (header, glTF 2.0 parse, meshes, triangle limit, bounds, textures, plan size) and stored as uploaded. The browser decodes Draco and Meshopt, so sellers can pre-compress, e.g. with `npx @gltf-transform/cli optimize in.glb out.glb`. Under Node (`npm run dev`, `next start`, the seed script), compression runs automatically.
- Uploads are capped by the seller's plan and by Cloudflare's 100 MB request-body limit (Free/Pro).
- MediaPipe task models load from Google's CDN by default. Override them with `NEXT_PUBLIC_MP_*` to self-host, for example in R2.

## Feature status (honest)

See `SKINIFY_BUILD_REPORT.md` for the full breakdown. Summary:

- **Working and verified:** discovery, search and filters; product and brand pages; favourites (stored locally); seller signup and login; brands; the 7-step Skinner wizard; GLB upload and validation; publish/unpublish/duplicate/delete; links; QR (SVG/PNG/print); iframe embed and SDK button; real analytics; configurable plans and limits; expiry handling; admin moderation; API keys and `/api/v1`.
- **Live AR:** ring was verified on a real hand image, and glasses on a real face image. Watch, bracelet, earrings, lips, nails, hat, necklace and surface placement are implemented but have not been validated on real devices. Bag, clothing overlay and shoes are experimental.
- **Requires external service:** online card payments (Stripe keys) and an R2 bucket for seller uploads.
